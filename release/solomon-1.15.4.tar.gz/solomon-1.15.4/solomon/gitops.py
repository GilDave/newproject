"""Git helpers: isolated worktrees, change collection, patch apply."""

from __future__ import annotations

import fnmatch
import os
import subprocess
import tempfile
from pathlib import Path

from .scope_guard import Change


class GitError(RuntimeError):
    pass


def git(args: list[str], cwd: str | Path, check: bool = True, timeout: float = 120.0,
        env: dict | None = None) -> subprocess.CompletedProcess:
    proc = subprocess.run(
        ["git", "-c", "core.quotepath=false", *args],
        cwd=str(cwd),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        shell=False,
        env=env,
    )
    if check and proc.returncode != 0:
        raise GitError(f"git {' '.join(args)} failed: {proc.stderr.strip() or proc.stdout.strip()}")
    return proc


def ensure_repo(project: Path) -> None:
    if not project.is_dir():
        raise GitError(f"project folder does not exist: {project}")
    if git(["rev-parse", "--is-inside-work-tree"], project, check=False).returncode != 0:
        raise GitError(f"not a git repository: {project}")
    if git(["rev-parse", "--verify", "HEAD"], project, check=False).returncode != 0:
        raise GitError(f"repository has no commits yet: {project} (make an initial commit first)")


def is_dirty(project: Path) -> bool:
    return bool(git(["status", "--porcelain"], project).stdout.strip())


def exclude_from_git(project: Path, name: str) -> None:
    """Keep the state folder out of `git status` without touching .gitignore."""
    raw = git(["rev-parse", "--git-path", "info/exclude"], project).stdout.strip()
    path = Path(raw) if Path(raw).is_absolute() else project / raw
    path.parent.mkdir(parents=True, exist_ok=True)
    line = name.rstrip("/") + "/"
    existing = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    if line not in existing:
        with path.open("a", encoding="utf-8") as fh:
            fh.write(("\n" if existing and existing[-1] else "") + line + "\n")


def create_worktree(project: Path, dest: Path, ref: str = "HEAD") -> None:
    """An isolated checkout of `ref` (a commit or branch name) as a detached HEAD."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    git(["worktree", "add", "--detach", str(dest), ref], project)


def resolve(project: Path, ref: str) -> str:
    return git(["rev-parse", "--verify", f"{ref}^{{commit}}"], project).stdout.strip()


def commit_all(wt: Path, message: str, name: str = "Solomon", email: str = "solomon@localhost") -> str:
    """Commit everything in the worktree under a fixed identity (never the user's), return the new commit id."""
    git(["add", "-A"], wt)
    git(["-c", f"user.name={name}", "-c", f"user.email={email}", "commit", "-q", "--no-verify", "-m", message], wt)
    return git(["rev-parse", "HEAD"], wt).stdout.strip()


def create_branch(project: Path, name: str, ref: str) -> None:
    git(["branch", name, ref], project)  # refuses an existing name: a batch never overwrites someone's branch


def move_branch(project: Path, name: str, commit: str) -> None:
    git(["update-ref", f"refs/heads/{name}", commit], project)


def diff_between(project: Path, base: str, tip: str) -> str:
    return git(["diff", "--binary", "--no-renames", base, tip], project).stdout


def remove_worktree(project: Path, dest: Path) -> None:
    git(["worktree", "remove", "--force", str(dest)], project, check=False)
    git(["worktree", "prune"], project, check=False)


def reset_worktree(wt: Path) -> None:
    git(["reset", "--hard", "HEAD"], wt)
    git(["clean", "-fd"], wt)


def clean_untracked(wt: Path) -> None:
    """Drop files created by the test run (e.g. __pycache__). collect_changes() staged the
    builder's work first, so only verification leftovers are still untracked here."""
    git(["clean", "-fdq"], wt, check=False)


def list_files(wt: Path, limit: int = 300) -> list[str]:
    files = git(["ls-files"], wt).stdout.splitlines()
    return files[:limit]


def collect_changes(wt: Path) -> list[Change]:
    git(["add", "-A"], wt)
    status = git(["diff", "--cached", "--name-status", "--no-renames"], wt).stdout.splitlines()
    numstat = git(["diff", "--cached", "--numstat", "--no-renames"], wt).stdout.splitlines()
    counts: dict[str, tuple[int, int]] = {}
    for line in numstat:
        parts = line.split("\t", 2)
        if len(parts) == 3:
            added = int(parts[0]) if parts[0].isdigit() else 0  # '-' marks a binary file
            removed = int(parts[1]) if parts[1].isdigit() else 0
            counts[parts[2]] = (added, removed)
    changes = []
    for line in status:
        code, _, path = line.partition("\t")
        added, removed = counts.get(path, (0, 0))
        changes.append(Change(path=path, status=code[:1], added=added, removed=removed))
    return changes


def full_diff(wt: Path, binary: bool = False) -> str:
    args = ["diff", "--cached", "--no-renames"] + (["--binary"] if binary else [])
    return git(args, wt).stdout


def apply_patch(project: Path, patch_file: Path) -> None:
    git(["apply", "--check", str(patch_file)], project)
    git(["apply", str(patch_file)], project)


SECRET_PATTERNS = (".env", ".env.*", "*.pem", "*.key", "*.p12", "id_rsa*", "id_ed25519*", "*.keystore", "credentials*.json", "secrets*.json")


def _is_secret(path: str) -> bool:
    name = path.rsplit("/", 1)[-1]
    return any(fnmatch.fnmatch(name, pat) for pat in SECRET_PATTERNS)


def snapshot_worktree(project: Path) -> tuple[str, list[str]]:
    """A commit object holding the project exactly as it is on disk right now (tracked edits and new files that are
    not git-ignored), built in a temporary index: the user's branch, index and files are not touched.
    Secret-looking files are left at their committed state (or left out), so they never reach an AI.
    Returns (commit id, files that differ from HEAD)."""
    with tempfile.TemporaryDirectory() as tmp:
        env = {**os.environ, "GIT_INDEX_FILE": str(Path(tmp) / "index")}
        git(["read-tree", "HEAD"], project, env=env)
        git(["add", "-A"], project, env=env)
        changed = git(["diff", "--cached", "--name-only", "HEAD"], project, env=env).stdout.splitlines()
        kept = []
        for path in changed:
            if _is_secret(path):
                if git(["cat-file", "-e", f"HEAD:{path}"], project, check=False).returncode == 0:
                    git(["reset", "-q", "HEAD", "--", path], project, env=env)
                else:
                    git(["rm", "--cached", "-q", "--", path], project, env=env)
            else:
                kept.append(path)
        tree = git(["write-tree"], project, env=env).stdout.strip()
    commit = git(["-c", "user.name=Solomon", "-c", "user.email=solomon@localhost", "commit-tree", tree, "-p", "HEAD",
                  "-m", "Solomon snapshot of the working folder"], project).stdout.strip()
    return commit, kept
