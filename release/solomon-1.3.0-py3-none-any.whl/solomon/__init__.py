"""Solomon: GPT x Claude cross-verified development pipeline."""

__version__ = "1.3.0"
